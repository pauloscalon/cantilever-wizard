"""
    This python file contains functions in SpaceClaim context
"""
import units

def createChannel(length, depth, web_thick, flange_width, flange_thick):
    """
        This method defines how to a Channel Beam
    """
    win = Window.ActiveWindow
    context = win.ActiveContext
    part = context.ActivePart

    L = length
    d = depth
    tw = web_thick
    bf = flange_width
    tf = flange_thick


    # Set Sketch Plane
    sectionPlane = Plane.PlaneXY
    result = ViewHelper.SetSketchPlane(sectionPlane, None)
    # EndBlock

    # Sketch Line - Depth definition
    midPoint = Point2D.Create(MM(0), MM(0))
    end = Point2D.Create(MM(0), MM(d/2))
    isConstruction = False
    centerline = True
    result = SketchLine.Create(midPoint, end, isConstruction, centerline)
    #EndBlock

    # Sketch Line - Width
    start = Point2D.Create(MM(0), MM(d/2))
    end = Point2D.Create(MM(bf), MM(d/2))
    result = SketchLine.Create(start, end)
    #EndBlock

    # Sketch Line - Upper Flange Thickness
    start = Point2D.Create(MM(bf), MM(d/2))
    end = Point2D.Create(MM(bf), MM(d/2-tf))
    result = SketchLine.Create(start, end)
    #EndBlock

    # Sketch Line - Upper Flange Width  
    start = Point2D.Create(MM(bf), MM(d/2-tf))
    end = Point2D.Create(MM(tw), MM(d/2-tf))
    result = SketchLine.Create(start, end)
    #EndBlock

    # Sketch Line - Web Depth
    start = Point2D.Create(MM(tw), MM(d/2-tf))
    end = Point2D.Create(MM(tw), MM(-d/2+tf))
    result = SketchLine.Create(start, end)
    #EndBlock
    
    # Sketch Line - Lower Flange Width
    start = Point2D.Create(MM(tw), MM(-d/2+tf))
    end = Point2D.Create(MM(bf), MM(-d/2+tf))
    result = SketchLine.Create(start, end)
    #EndBlock

    # Sketch Line - Lower Flange Thickness
    start = Point2D.Create(MM(bf), MM(-d/2+tf))
    end = Point2D.Create(MM(bf), MM(-d/2))
    result = SketchLine.Create(start, end)
    #EndBlock

    # Sketch Line - Width
    start = Point2D.Create(MM(bf), MM(-d/2))
    end = Point2D.Create(MM(0), MM(-d/2))
    result = SketchLine.Create(start, end)
    #EndBlock

    # Solidify Sketch
    mode = InteractionMode.Solid
    result = ViewHelper.SetViewMode(mode)
    # EndBlock

    # Solidify Sketch
    mode = InteractionMode.Solid
    result = ViewHelper.SetViewMode(mode, None)
    # EndBlock

    # Extrude 1 Face
    selection = Selection.Create(GetRootPart().Bodies[0].Faces[0])
    options = ExtrudeFaceOptions()
    options.ExtrudeType = ExtrudeType.Add
    result = ExtrudeFaces.Execute(selection, MM(L), options)
    # EndBlock


def UpdateChannel(step):
    """
        This method creates the geometry
    """
    length = step.Properties["Geometry/Length"].Value
    depth = step.Properties["Geometry/Depth"].Value
    web_thick = step.Properties["Geometry/Web Thickness"].Value
    flange_width = step.Properties["Geometry/Flanges Width"].Value
    flange_thick = step.Properties["Geometry/Flanges Thickness"].Value

    createChannel (length, depth, web_thick, flange_width, flange_thick)

    return True

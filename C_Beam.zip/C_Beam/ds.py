"""
    This python file contains functions in Mechanical context
"""
def IsLocationValid(step, prop):
    """
        Checking the validity of the property
    """
    if prop.Value==None:
        return False
    if prop.Value.Ids.Count!=1:
        prop.StateMessage = "Select only one edge."
        return False
    return True

def CreateMeshControls(step):
    """
        Creating mesh controls
    """
    model = ExtAPI.DataModel.Project.Model
    mesh = model.Mesh
    sizing = mesh.AddSizing()
    sel = step.Properties["Sizing/Location"].Value
    entity = ExtAPI.DataModel.GeoData.GeoEntityById(sel.Ids[0])
    len = entity.Length
    ids = []
    for part in ExtAPI.DataModel.GeoData.Assemblies[0].Parts:
        for body in part.Bodies:
            for edge in  body.Edges:
                if abs(edge.Length-len)/len<1.e-6:
                    ids.Add(edge.Id)
    sel = ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities)
    sel.Ids = ids
    sizing.Location = sel
    sizing.Type = SizingType.NumberOfDivisions
    sizing.NumberOfDivisions = step.Properties["Sizing/Ndiv"].Value
    step.Attributes.SetValue("sizing", sizing)
    mesh.GenerateMesh()

def RemoveControls(step):
    """
        Deleting mesh controls
    """
    sizing = step.Attributes["sizing"]
    sizing.Delete()

def IsLocationFSValid(step, prop):
    """
        Checking the validity of the property
    """
    if prop.Value==None:
        return False
    if prop.Value.Ids.Count!=1:
        prop.StateMessage = "Select only one face."
        return False
    return True

def IsLocationRLValid(step, prop):
    """
        Checking the property validity
    """
    if prop.Value==None:
        return False
    if prop.Value.Ids.Count!=1:
        prop.StateMessage = "Select only one face."
        return False
    return True

def RefreshLoads(step):
    """
        Displays mesh information
    """
    model = ExtAPI.DataModel.Project.Model
    step.Properties["Mesh/Nodes"].Value = model.Mesh.Nodes.ToString()
    step.Properties["Mesh/Elements"].Value = model.Mesh.Elements.ToString()
    panel = step.UserInterface.GetComponent("Properties")
    panel.UpdateData()
    panel.Refresh()
    
def CreateLoads(step):
    """
        Method to create the boundary conditions
    """
    model = ExtAPI.DataModel.Project.Model
    analysis = model.Analyses[0]
    support = analysis.AddFixedSupport()
    sel = step.Properties["FixedSupport/Location"].Value
    entity = ExtAPI.DataModel.GeoData.GeoEntityById(sel.Ids[0])
    area = entity.Area
    ids = []
    #for part in ExtAPI.DataModel.GeoData.Assemblies[0].Parts:
    #    for body in part.Bodies:
    #        for face in  body.Faces:
    #            if abs(face.Area-area)/area<1.e-6:
    #                ids.Add(face.Id)
    #sel = ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities)
    #sel.Ids = ids
    support.Location = sel
    loads = []
    loads.Add(support)
    step.Attributes.SetValue("loads", loads)

    remoteload = analysis.AddRemoteForce()
    sel = step.Properties["RemoteLoad/Location"].Value
    entity = ExtAPI.DataModel.GeoData.GeoEntityById(sel.Ids[0])
    area = entity.Area
    ids = []
    #for part in ExtAPI.DataModel.GeoData.Assemblies[0].Parts:
    #    for body in part.Bodies:
    #        for face in  body.Faces:
    #            if abs(face.Area-area)/area<1.e-6:
    #                ids.Add(face.Id)
    #sel = ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities)
    #sel.Ids = ids

    #Sets the selected face as scope of the remote load
    remoteload.Location = sel

    #Defining load by components (X, Y or Z)
    remoteload.DefineBy = LoadDefineBy.Components

    #Retrieves user input
    magnitude = step.Properties["RemoteLoad/Mag"].Value
    remoteload.YComponent.Output.SetDiscreteValue(0, Quantity(-magnitude, "N"))
    remoteload.Behavior = LoadBehavior.Rigid

    #X coordinate of remote load - Retrieves user input for shear center position
    e_pos = step.Properties["RemoteLoad/ePos"].Value
    remoteload.XCoordinate = Quantity(-e_pos,"mm")
    loads.Add(remoteload)
    step.Attributes.SetValue("loads", loads) 
    
    #Creates Earth Gravity -Y
    earth_gravity = analysis.AddEarthGravity()
    earth_gravity.Direction = GravityOrientationType.NegativeYAxis
    loads.Add(earth_gravity)
    #Ends Earth Gravity

    res = analysis.Solution.AddDirectionalDeformation()
    res.NormalOrientation = NormalOrientationType.YAxis
    res.Name = r"""Deflection"""
    step.Attributes.SetValue("res", res)
    loads.Add(res)


    res1 = analysis.Solution.AddNormalStress()
    res1.NormalOrientation = NormalOrientationType.ZAxis
    step.Attributes.SetValue("res1", res1)
    loads.Add(res1)

    res2 = analysis.Solution.AddShearStress()
    res2.ShearOrientation = ShearOrientationType.XZPlane
    res2.Name = r"""Shear Stress XZ"""
    loads.Add(res2)

    res3 = analysis.Solution.AddShearStress()
    res3.ShearOrientation = ShearOrientationType.YZPlane
    res3.Name = r"""Shear Stress YZ"""
    loads.Add(res3)

    analysis.Solve(True)

    ExtAPI.Extension.SetAttributeValueWithSync("result", res.Maximum.ToString())
    ExtAPI.Extension.SetAttributeValueWithSync("result", res1.Maximum.ToString())

def RemoveLoads(step):
    """
        Deleting boundary conditions
    """
    loads = step.Attributes["loads"]
    for load in loads:
        load.Delete()


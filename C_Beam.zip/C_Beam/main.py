"""
    This python file contains functions in Project Schematic context
"""
def CreateStaticStructural(step):
    """
        Create a Static Structural system
    """
    template1 = GetTemplate(
        TemplateName="Static Structural",
        Solver="ANSYS")
    system1 = template1.CreateSystem()
    system1.DisplayText = step.Properties["Name"].Value

    nextStep = step.NextStep
    # defining on which component the next steps will be
    if nextStep!=None:
        nextStep.SystemName = system1.Name
        nextStep.ComponentName = "Geometry"
    nextStep = nextStep.NextStep
    if nextStep!=None:
        nextStep.SystemName = system1.Name
        nextStep.ComponentName = "Geometry"
    nextStep = nextStep.NextStep
    if nextStep!=None:
        nextStep.SystemName = system1.Name
        nextStep.ComponentName = "Model"
    nextStep = nextStep.NextStep
    if nextStep!=None:
        nextStep.SystemName = system1.Name
        nextStep.ComponentName = "Model"
    nextStep = nextStep.NextStep
    if nextStep!=None:
        nextStep.SystemName = system1.Name
        nextStep.ComponentName = "Model"

def OnSelectContext(step, prop):
    """
        If Design Modeler is selected SpaceClaim's step isn't available, and vice versa
    """
    DMStep = step.NextStep
    SCStep = DMStep.NextStep

    if prop.Value == "DesignModeler":
        DMStep.IsEnabled = True
        SCStep.IsEnabled = False
    elif prop.Value == "SpaceClaim":
        DMStep.IsEnabled = False
        SCStep.IsEnabled = True

    panel = step.UserInterface.Panel.GetComponent("Steps")
    panel.UpdateData()
    panel.Refresh()

def RefreshResultsProject(step):
    """
        Displays the maximum deformation
    """
    model = ExtAPI.DataModel.Project.Model
    res = step.PreviousStep.Attributes["res"]
    step.Properties["Res"].Value = res.Maximum.ToString()
    panel = step.UserInterface.GetComponent("Properties")
    panel.UpdateData()
    panel.Refresh()
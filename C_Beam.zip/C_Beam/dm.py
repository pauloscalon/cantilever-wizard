"""
    This python file contains functions in Design Modeler context
"""
import units

def GenerateCube(feature,fct):
    """ 
        This method define how the cube is created
    """
    length = feature.Properties["Length"].Value
    length = units.ConvertUnit(length, ExtAPI.DataModel.CurrentUnitFromQuantityName("Length"), "m") 
    width = feature.Properties["Width"].Value
    width = units.ConvertUnit(width, ExtAPI.DataModel.CurrentUnitFromQuantityName("Length"), "m") 
    height = feature.Properties["Height"].Value
    height = units.ConvertUnit(height, ExtAPI.DataModel.CurrentUnitFromQuantityName("Length"), "m") 

    
    builder = ExtAPI.DataModel.GeometryBuilder
    
    bodies = []
    
    boxGen = builder.Primitives.Solid.CreateBox([0.,-width/2.,-height/2.0],[length,width/2.,height/2.0])
    bodies.Add(boxGen.Generate())    
    
    feature.Bodies = bodies
    feature.MaterialType = MaterialTypeEnum.Add

    return True
    
    
def UpdateCube(step):
    """
        This method creates the geometry
    """
    Cube = ExtAPI.CreateFeature("Cube")
    Cube.Properties["Length"].Value = step.Properties["Geometry/Length"].Value
    Cube.Properties["Width"].Value = step.Properties["Geometry/Width"].Value
    Cube.Properties["Height"].Value = step.Properties["Geometry/Height"].Value
    ExtAPI.DataModel.FeatureManager.Generate()
    